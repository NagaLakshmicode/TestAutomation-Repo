package RestAssuredBasics;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;




public class MyPractice1 {

	public static void main(String[] args) {
		
		String ActualLastname="Weaver";
		String ActualEmail="janet.weaver@reqres.in";
		int ActialId=2;
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=given().log().all().header("Connection","keep-alive")
		.when().get("api/users/2")
		.then().log().all().assertThat().statusCode(200).
		body("data.first_name",equalTo("Janet")).
		header("Server", "cloudflare").
				
		extract().response().asString();
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
		String LastName=js.getString("data.last_name");
		Assert.assertEquals(ActualLastname, LastName);
		
		String email=js.getString("data.email");
		int id=js.getInt("data.id");
		Assert.assertEquals(ActualEmail, email);
		Assert.assertEquals(ActialId, id);
		
		System.out.println("My test case passed");
		

	}

}
