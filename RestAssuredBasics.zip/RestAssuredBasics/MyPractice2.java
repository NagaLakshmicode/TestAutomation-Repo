package RestAssuredBasics;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class MyPractice2 {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=given().log().all().queryParam("page", 2).
		header("Connection", "keep-alive").
		when().get("api/users").
		then().log().all().
		assertThat().statusCode(200).
		extract().response().asString();
		
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
        String ExpectedFirstName=js.getString("data[3].first_name");
        int ExpectedId=js.getInt("data[5].id");
        int Expectedper_page=js.getInt("per_page");
        
        
	}

}
